/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author srivaishnaviaekkati
 */
public class Complaints_Suggestions_Request extends StatusRequest{
    
    private String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

   
    
}
